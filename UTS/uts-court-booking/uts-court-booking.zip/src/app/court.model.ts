export class Court {
  constructor(
      public id: string,
      public name: string,
      public imageUrl: string,
      public city: string,
      public type: string,
  ) {}
}